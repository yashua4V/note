git 软件安装
yum install -y git

外地校区
git clone git://124.193.128.166/nsd1806.git

本地
git clone git://172.40.53.65/nsd1806.git

更新(必须进入 git 目录)
git  pull
